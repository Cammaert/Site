# -*- coding: utf-8 -*-
{
    'name': 'Auto Backup to Google Cloud Storage',
    'author': 'Great-IT',
    'version': '14.0.1.0.0',
    'category': 'Hidden',
    'depends': ['auto_backup', 'google_cloud_storage'],
    'data': [
        'security/ir.model.access.csv',
        'data/backup_data.xml',
        'views/db_backup_history.xml',
        'views/db_backup.xml',
    ],
    'installable': True,
}
