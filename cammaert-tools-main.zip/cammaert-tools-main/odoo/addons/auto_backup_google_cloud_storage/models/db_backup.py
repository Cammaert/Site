# -*- coding: utf-8 -*-
import os

from odoo import api, fields, models


class DbBackup(models.Model):
    _inherit = 'db.backup'

    google_storage_id = fields.Many2one(
        comodel_name='google.cloud.storage', string='Google Cloud Storage',
    )
    backup_method = fields.Selection(
        selection=[
            ('google_storage', 'Google Cloud Storage'),
            ('sftp_server', 'SFTP Server'),
        ],
        string='Backup Destination',
    )
    backup_history_ids = fields.One2many(
        comodel_name='db.backup.history',
        inverse_name='db_backup_id',
        string='Histories',
    )

    def schedule_backup_sftp(self):
        self.schedule_backup()

    def schedule_backup_google_storage(self):
        try:
            backup_filename = '{0}_{1}.{2}'.format(
                fields.Datetime.now().strftime('%Y_%m_%d_%H_%M_%S'),
                self.name,
                self.backup_type,
            )
            backup_filepath = os.path.join(self.folder, backup_filename)
            with open(backup_filepath, 'wb') as backup_file:
                self._take_dump(
                    self.name, backup_file, 'db.backup', self.backup_type
                )

            self.google_storage_id.upload(backup_filepath)
            self._add_history(backup_filename)
            self.delete_backup_google_storage()
        except Exception:
            raise

    def delete_backup_google_storage(self):
        if self.autoremove:
            self.google_storage_id.delete(self.days_to_keep)

    def _add_history(self, filename):
        self.env['db.backup.history'].create(
            {
                'db_backup_id': self.id,
                'filename': filename,
                'backup_method': dict(
                    self._fields['backup_method'].selection
                ).get(self.backup_method),
            }
        )

    @api.model
    def cron_schedule_backup(self):
        for record in self.search([]):
            if record.backup_method == 'sftp_server':
                record.schedule_backup_sftp()
            elif record.backup_method == 'google_storage':
                record.schedule_backup_google_storage()
