# -*- coding: utf-8 -*-
from odoo import fields, models


class DbBackupHistory(models.Model):
    _name = 'db.backup.history'
    _description = 'DB Backup History'

    db_backup_id = fields.Many2one(
        comodel_name='db.backup',
        required=True,
        ondelete='cascade',
        string='Backup',
    )
    filename = fields.Char(required=True, string='Filename',)
    backup_method = fields.Char(required=True, string='Backup Destination',)
