# -*- coding: utf-8 -*-
from .hooks import post_init_hook
