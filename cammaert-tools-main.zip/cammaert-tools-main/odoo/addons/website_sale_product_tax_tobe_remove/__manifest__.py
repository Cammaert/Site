# -*- coding: utf-8 -*-
{
    'name': 'Website Sale Product Tax',
    'author': 'Great-IT',
    'version': '14.0.1.0.0',
    'category': 'Website/Website',
    'sequence': 1000,
    'depends': ['website_sale'],
    'data': ['templates/templates.xml'],
    'installable': True,
}
