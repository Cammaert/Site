# -*- coding: utf-8 -*-
from odoo.addons.sale.models import product_template
from odoo.addons.website_sale.models import product

_original_get_combination_info = (
    product_template.ProductTemplate._get_combination_info
)


def _get_combination_info(
    self,
    combination=False,
    product_id=False,
    add_qty=1,
    pricelist=False,
    parent_combination=False,
    only_template=False,
):
    """Overwrite method"""
    self.ensure_one()

    current_website = False

    if self.env.context.get('website_id'):
        current_website = self.env['website'].get_current_website()
        if not pricelist:
            pricelist = current_website.get_current_pricelist()

    combination_info = _original_get_combination_info(
        self=self,
        combination=combination,
        product_id=product_id,
        add_qty=add_qty,
        pricelist=pricelist,
        parent_combination=parent_combination,
        only_template=only_template,
    )

    if self.env.context.get('website_id'):
        partner = self.env.user.partner_id
        company_id = current_website.company_id
        product = (
            self.env['product.product'].browse(combination_info['product_id'])
            or self
        )

        tax_display = (
            self.user_has_groups(
                'account.group_show_line_subtotals_tax_excluded'
            )
            and 'total_excluded'
            or 'total_included'
        )
        fpos = (
            self.env['account.fiscal.position']
            .get_fiscal_position(partner.id)
            .sudo()
        )
        taxes = fpos.map_tax(
            product.sudo().taxes_id.filtered(
                lambda x: x.company_id == company_id
            ),
            product,
            partner,
        )
        # The list_price is always the price of one.
        quantity_1 = 1
        price_total = taxes.compute_all(
            combination_info['price'],
            pricelist.currency_id,
            quantity_1,
            product,
            partner,
        )
        price = price_total[tax_display]
        if pricelist.discount_policy == 'without_discount':
            product_price = taxes.compute_all(
                combination_info['list_price'],
                pricelist.currency_id,
                quantity_1,
                product,
                partner,
            )
            list_price_without_tax = product_price['total_excluded']
            list_price = product_price[tax_display]
        else:
            list_price_without_tax = price_total['total_excluded']
            list_price = price

        has_discounted_price = (
            pricelist.currency_id.compare_amounts(list_price, price) == 1
        )

        combination_info.update(
            price=price,
            list_price=list_price,
            has_discounted_price=has_discounted_price,
            list_price_without_tax=list_price_without_tax,
            price_tax_display_conf=tax_display,
        )

    return combination_info


product.ProductTemplate._get_combination_info = _get_combination_info
