# -*- coding: utf-8 -*-
# License AGPL-3
from . import models
from . import controllers
from .hooks import uninstall_hook
