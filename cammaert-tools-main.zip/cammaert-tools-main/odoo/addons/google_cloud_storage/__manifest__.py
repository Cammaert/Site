# -*- coding: utf-8 -*-
{
    'name': 'Google Cloud Storage',
    'author': 'Great-IT',
    'version': '14.0.1.0.0',
    'category': 'Hidden',
    'depends': ['base'],
    'data': ['security/ir.model.access.csv', 'views/google_cloud_storage.xml'],
    'installable': True,
    'external_dependencies': {'python': ['google']},
}
