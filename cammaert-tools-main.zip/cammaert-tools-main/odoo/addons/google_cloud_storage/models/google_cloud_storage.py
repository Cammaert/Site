# -*- coding: utf-8 -*-
import os
from datetime import datetime

try:
    from google.cloud import storage
except ImportError:
    raise ImportError(
        'This module needs google.cloud to be able to connect to Google Cloud Storage  Service '
        'Please install google.cloud on your system. (sudo pip3 install google-cloud-storage)'
    )


from odoo import _, api, exceptions, fields, models
from odoo.tools.config import config


class GoogleCloudStorage(models.Model):
    _name = 'google.cloud.storage'
    _description = 'Google Cloud Storage'
    _rec_name = 'bucket_name'

    service_account = fields.Binary(string='Service Account', required=True,)
    service_account_filename = fields.Char(string='Filename')
    bucket_name = fields.Char(string='Bucket', required=True)
    folder_name = fields.Char(string='Folder', help='Folder in bucket',)
    active = fields.Boolean(default=True)
    last_sent = fields.Datetime(string='Last Sent')

    _sql_constraints = [
        ('unique_name', 'UNIQUE(bucket_name)', 'Bucket name must be unique!')
    ]

    @api.constrains('service_account_filename')
    def _check_account_filename(self):
        for record in self:
            _name, file_ext = os.path.splitext(record.service_account_filename)
            if file_ext.lower() != '.json':
                raise exceptions.UserError(
                    _('File type is not correct. Required JSON file')
                )

    def _get_service_account_path(self):
        attachment_id = (
            self.env['ir.attachment']
            .sudo()
            .search(
                [
                    ('res_id', '=', self.id),
                    ('res_model', '=', self._name),
                    ('res_field', '=', 'service_account'),
                ]
            )
        )
        service_account_path = None
        if attachment_id:
            service_account_path = os.path.join(
                config.get('data_dir'),
                'filestore',
                self.env.cr.dbname,
                attachment_id.checksum[:2],
                attachment_id.checksum,
            )
        return service_account_path

    def action_check_connection(self):
        self.ensure_one()
        service_account_path = self._get_service_account_path()
        if service_account_path and os.path.isfile(service_account_path):
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = service_account_path
            try:
                client = storage.Client()
                bucket = client.get_bucket(self.bucket_name)
                blob = bucket.blob('odoo/hello.txt')
                # test upload a file
                blob.upload_from_string('This is a Odoo test file')
                # and then delete
                blob.delete()
                raise exceptions.UserError(_('Connection successfully'))
            except Exception as err:
                raise exceptions.UserError(str(err))

    def upload(self, source_file_path):
        service_account_path = self._get_service_account_path()
        if service_account_path and os.path.isfile(service_account_path):
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = service_account_path
            try:
                storage_client = storage.Client()
                bucket = storage_client.bucket(self.bucket_name)
                _path, file_name = os.path.split(source_file_path)
                destination_blob_name = file_name
                if self.folder_name:
                    destination_blob_name = '{}/{}'.format(
                        self.folder_name, file_name
                    )

                blob = bucket.blob(destination_blob_name)
                blob.upload_from_filename(source_file_path)
                self.write({'last_sent': fields.Datetime.now()})
                os.remove(source_file_path)
            except Exception as err:
                raise exceptions.UserError(str(err))

    def delete(self, days_to_kept):
        service_account_path = self._get_service_account_path()
        if service_account_path and os.path.isfile(service_account_path):
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = service_account_path
            try:
                storage_client = storage.Client()
                blobs = storage_client.list_blobs(self.bucket_name)
                now = datetime.now()
                for blob in blobs:
                    delta = now.date() - blob.time_created.date()
                    if delta.days >= days_to_kept:
                        blob.delete()

            except Exception as err:
                raise exceptions.UserError(str(err))
