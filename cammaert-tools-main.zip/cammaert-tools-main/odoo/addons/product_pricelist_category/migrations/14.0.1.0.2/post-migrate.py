# -*- coding: utf-8 -*-
def migrate(cr, version):
    cr.execute(
        '''
        UPDATE product_template SET pricelist_categ_id = (
            SELECT pricelist_categ_id
            FROM product_template_product_pricelist_category_rel
            WHERE product_templ_id = product_template.id LIMIT 1
        )
        '''
    )
    cr.execute(
        'DROP TABLE IF EXISTS product_template_product_pricelist_category_rel'
    )
