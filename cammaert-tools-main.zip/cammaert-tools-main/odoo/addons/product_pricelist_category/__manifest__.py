# -*- coding: utf-8 -*-
{
    'name': 'Product Pricelist Category',
    'author': 'Great-IT',
    'version': '14.0.1.0.2',
    'category': 'Hidden',
    'depends': ['product', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/product_pricelist_category.xml',
        'views/product_template.xml',
        'views/product_pricelist_item.xml',
    ],
    'installable': True,
}
