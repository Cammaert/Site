# -*- coding: utf-8 -*-
from odoo import _, api, exceptions, fields, models


class ProductPricelistItem(models.Model):
    _inherit = 'product.pricelist.item'

    applied_on = fields.Selection(
        selection_add=[
            ('4_product_pricelist_categ', 'Product Pricelist Category')
        ],
        ondelete={
            '4_product_pricelist_categ': lambda recs: recs.write(
                {'applied_on': '2_product_category'}
            )
        },
    )
    pricelist_categ_id = fields.Many2one(
        comodel_name='product.pricelist.category', string='Pricelist Category',
    )

    @api.constrains('product_id', 'product_tmpl_id', 'categ_id')
    def _check_product_consistency(self):
        super(ProductPricelistItem, self)._check_product_consistency()
        for item in self:
            if (
                item.applied_on == '4_product_pricelist_categ'
                and not item.pricelist_categ_id
            ):
                raise exceptions.ValidationError(
                    _(
                        'Please specify the pricelist category for which this rule should be applied'
                    )
                )

    @api.depends(
        'applied_on',
        'categ_id',
        'product_tmpl_id',
        'product_id',
        'compute_price',
        'fixed_price',
        'pricelist_id',
        'percent_price',
        'price_discount',
        'price_surcharge',
    )
    def _get_pricelist_item_name_price(self):
        super(ProductPricelistItem, self)._get_pricelist_item_name_price()

        for item in self:
            if (
                item.pricelist_categ_id
                and item.applied_on == '4_product_pricelist_categ'
            ):
                item.name = _('Pricelist Category: %s') % (
                    item.pricelist_categ_id.display_name
                )

    @api.model_create_multi
    def create(self, vals_list):
        for values in vals_list:
            if values.get('applied_on', False):
                # Ensure item consistency for later searches.
                applied_on = values['applied_on']
                if applied_on == '3_global':
                    values.update(
                        dict(
                            product_id=None,
                            product_tmpl_id=None,
                            categ_id=None,
                            pricelist_categ_id=None,
                        )
                    )
                elif applied_on == '2_product_category':
                    values.update(
                        dict(
                            product_id=None,
                            product_tmpl_id=None,
                            pricelist_categ_id=None,
                        )
                    )
                elif applied_on == '1_product':
                    values.update(
                        dict(
                            product_id=None,
                            categ_id=None,
                            pricelist_categ_id=None,
                        )
                    )
                elif applied_on == '0_product_variant':
                    values.update(dict(categ_id=None, pricelist_categ_id=None))
                elif applied_on == '4_product_pricelist_categ':
                    values.update(
                        dict(
                            product_id=None,
                            product_tmpl_id=None,
                            categ_id=None,
                        )
                    )

        return super(ProductPricelistItem, self).create(vals_list)

    def write(self, values):
        if values.get('applied_on', False):
            # Ensure item consistency for later searches.
            applied_on = values['applied_on']
            if applied_on == '3_global':
                values.update(
                    dict(
                        product_id=None,
                        product_tmpl_id=None,
                        categ_id=None,
                        pricelist_categ_id=None,
                    )
                )
            elif applied_on == '2_product_category':
                values.update(
                    dict(
                        product_id=None,
                        product_tmpl_id=None,
                        pricelist_categ_id=None,
                    )
                )
            elif applied_on == '1_product':
                values.update(
                    dict(
                        product_id=None, categ_id=None, pricelist_categ_id=None
                    )
                )
            elif applied_on == '0_product_variant':
                values.update(dict(categ_id=None, pricelist_categ_id=None))
            elif applied_on == '4_product_pricelist_categ':
                values.update(
                    dict(product_id=None, product_tmpl_id=None, categ_id=None)
                )
        return super(ProductPricelistItem, self).write(values)
