# -*- coding: utf-8 -*-
from odoo import models


class ProductProduct(models.Model):
    _inherit = 'product.product'

    def _compute_variant_item_count(self):
        """Overwrite method"""
        for product in self:
            domain = [
                '|',
                '|',
                '&',
                ('product_tmpl_id', '=', product.product_tmpl_id.id),
                ('applied_on', '=', '1_product'),
                '&',
                ('product_id', '=', product.id),
                ('applied_on', '=', '0_product_variant'),
                '&',
                ('pricelist_categ_id', '=', product.pricelist_categ_id.id),
                ('applied_on', '=', '4_product_pricelist_categ'),
            ]
            product.pricelist_item_count = self.env[
                'product.pricelist.item'
            ].search_count(domain)

    def open_pricelist_rules(self):
        """Override method"""
        res = super(ProductProduct, self).open_pricelist_rules()
        domain = res.get('domain') or []
        domain.extend(
            [
                '&',
                ('pricelist_categ_id', '=', self.pricelist_categ_id.id),
                ('applied_on', '=', '4_product_pricelist_categ'),
            ]
        )
        domain.insert(0, '|')
        res['domain'] = domain
        return res
