# -*- coding: utf-8 -*-
from odoo import models


class ProductPricelist(models.Model):
    _inherit = 'product.pricelist'

    def _compute_price_rule_get_items(
        self,
        products_qty_partner,
        date,
        uom_id,
        prod_tmpl_ids,
        prod_ids,
        categ_ids,
    ):
        res = super(ProductPricelist, self)._compute_price_rule_get_items(
            products_qty_partner=products_qty_partner,
            date=date,
            uom_id=uom_id,
            prod_tmpl_ids=prod_tmpl_ids,
            prod_ids=prod_ids,
            categ_ids=categ_ids,
        )
        product_pricelist_categ = []
        if prod_tmpl_ids:
            for tmpl in self.env['product.template'].browse(prod_tmpl_ids):
                product_pricelist_categ.append(tmpl.pricelist_categ_id.id)

        if prod_ids:
            for prod in self.env['product.product'].browse(prod_ids):
                product_pricelist_categ.append(prod.pricelist_categ_id.id)

        if product_pricelist_categ:
            result = res.filtered(
                lambda item: item.pricelist_categ_id.id
                in product_pricelist_categ
            )
            if result:
                return result[0]
        return res
