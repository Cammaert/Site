# -*- coding: utf-8 -*-
from . import product_pricelist_category
from . import product_pricelist_item
from . import product_template
from . import product_product
from . import product_pricelist
