# -*- coding: utf-8 -*-
from odoo import _, fields, models


class ProductPricelistCategory(models.Model):
    _name = 'product.pricelist.category'
    _description = 'Pricelist Category'

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)

    _sql_constraints = [
        ('name_unique', 'UNIQUE(name)', _('Name must be unique!'))
    ]
