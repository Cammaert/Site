# -*- coding: utf-8 -*-
{
    'name': 'Website Sale Product Tax',
    'author': 'Great-IT',
    'version': '14.0.1.0.0',
    'category': 'Website/Website',
    'sequence': 1000,
    'depends': ['website_sale'],
    'data': [
        'data/product_dynamic_filter.xml',
        'views/product_template.xml',
        'templates/templates.xml',
    ],
    'qweb': ['static/src/xml/*.xml'],
    'installable': True,
}
