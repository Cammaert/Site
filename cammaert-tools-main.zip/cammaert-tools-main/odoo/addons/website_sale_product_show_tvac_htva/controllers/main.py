# -*- coding: utf-8 -*-
from odoo.http import request

from odoo.addons.website_sale.controllers.main import WebsiteSale


class WebsiteSaleTvacHtva(WebsiteSale):
    def _get_products_recently_viewed(self):
        res = super(WebsiteSaleTvacHtva, self)._get_products_recently_viewed()
        products = res.get('products')
        if products:
            FieldMonetary = request.env['ir.qweb.field.monetary']
            monetary_options = {
                'display_currency': request.website.get_current_pricelist().currency_id,
            }
            for product in products:
                product[
                    'website_original_sale_price'
                ] = FieldMonetary.value_to_html(
                    product['website_original_sale_price'], monetary_options
                )

        return res
