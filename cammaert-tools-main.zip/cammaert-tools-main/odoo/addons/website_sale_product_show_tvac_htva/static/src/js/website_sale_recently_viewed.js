odoo.define('website_sale_product_show_tvac_htva.product_recently_viewed', function(require){
    'use strict';

    var core = require('web.core');
    const publicWidget = require('web.public.widget');
    var qweb = core.qweb;

    publicWidget.registry.productsRecentlyViewedSnippet.include({
        xmlDependencies: ['/website_sale_product_show_tvac_htva/static/src/xml/website_sale_recently_viewed.xml'],
        /**
         * @private
         */
        _render: function (res) {
            var products = res['products'];
            var mobileProducts = [], webProducts = [], productsTemp = [];
            _.each(products, function (product) {
                if (productsTemp.length === 4) {
                    webProducts.push(productsTemp);
                    productsTemp = [];
                }
                productsTemp.push(product);
                mobileProducts.push([product]);
            });
            if (productsTemp.length) {
                webProducts.push(productsTemp);
            }
            this.mobileCarousel = $(qweb.render('website_sale_product_show_tvac_htva.productsRecentlyViewed', {
                uniqueId: this.uniqueId,
                productFrame: 1,
                productsGroups: mobileProducts,
            }));
            this.webCarousel = $(qweb.render('website_sale_product_show_tvac_htva.productsRecentlyViewed', {
                uniqueId: this.uniqueId,
                productFrame: 4,
                productsGroups: webProducts,
            }));
            this._addCarousel();
            this.$el.toggleClass('d-none', !(products && products.length));
        },
    });
});
