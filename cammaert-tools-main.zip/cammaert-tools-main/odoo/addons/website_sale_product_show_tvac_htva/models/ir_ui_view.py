# -*- coding: utf-8 -*-
from odoo import models


class IrUiView(models.Model):
    _inherit = 'ir.ui.view'

    def write(self, values):
        res = super(IrUiView, self).write(values)
        if 'active' in values:
            toogle_show_tva_htva = False
            for view in self:
                if (
                    view.key
                    == 'website_sale_product_show_tvac_htva.products_item_show_tva_htva'
                ):
                    toogle_show_tva_htva = True
                    break

            product_price_show_tva_htva = self.sudo().env.ref(
                'website_sale_product_show_tvac_htva.product_price_show_tva_htva',
                raise_if_not_found=False,
            )
            if toogle_show_tva_htva and product_price_show_tva_htva:
                product_price_show_tva_htva.write({'active': values['active']})

        return res
