# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    @api.depends('list_price', 'website_tax_id', 'currency_id')
    def _compute_product_website_list_price(self):
        for product in self.sudo():
            if product.website_tax_id:
                product.website_list_price = product.website_tax_id.compute_all(
                    price_unit=product.list_price,
                    currency=product.currency_id,
                    product=product,
                )[
                    'total_included'
                ]
            else:
                product.website_list_price = product.list_price

    @api.depends('list_price')
    def _compute_website_original_sale_price(self):
        for product in self.sudo():
            product.website_original_sale_price = product.list_price

    website_list_price = fields.Float(
        string='Website TVAC Sale Price',
        compute='_compute_product_website_list_price',
        digits='Product Price',
        help=(
            'The sale price is managed from the product template. '
            "Click on the 'Configure Variants' button to set "
            'the extra attribute prices.'
        ),
        default=1.0,
    )
    website_tax_id = fields.Many2one(
        comodel_name='account.tax',
        string='Website Tax',
        domain=[('type_tax_use', '=', 'sale')],
        default=lambda self: self.env.company.account_sale_tax_id,
    )
    website_original_sale_price = fields.Float(
        compute='_compute_website_original_sale_price',
        compute_sudo=True,
        store=True,
    )

    def _get_combination_info(
        self,
        combination=False,
        product_id=False,
        add_qty=1,
        pricelist=False,
        parent_combination=False,
        only_template=False,
    ):
        combination_info = super(ProductTemplate, self)._get_combination_info(
            combination=combination,
            product_id=product_id,
            add_qty=add_qty,
            pricelist=pricelist,
            parent_combination=parent_combination,
            only_template=only_template,
        )
        view_qweb_option_id = (
            self.sudo()
            .env['ir.ui.view']
            .search([('name', '=', 'Show TVAC/HTVA'), ('type', '=', 'qweb')])
        )

        product_id = self.env['product.product'].browse(
            combination_info['product_id']
        )
        is_show_tva = any(o.active for o in view_qweb_option_id)

        combination_info[
            'website_original_sale_price'
        ] = product_id.website_original_sale_price
        if not is_show_tva:
            return combination_info

        if self.env.context.get('website_id'):
            product = product_id or self
            list_price = price = product.website_list_price
            combination_info.update(
                list_price=list_price, price=price,
            )

        return combination_info
