# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from odoo.osv import expression

from odoo.addons.website_sale.controllers.main import WebsiteSale


class WebsiteSalePaymentRestriction(WebsiteSale):
    @http.route(['/shop/payment'], type='http', auth='public', website=True)
    def payment(self, **post):
        response = super(WebsiteSalePaymentRestriction, self).payment(**post)
        order = response.qcontext.get('order') or response.qcontext.get(
            'website_sale_order'
        )
        partner_id = False
        if order:
            partner_id = order.partner_id
        elif response.qcontext.get('partner'):
            partner_id = request.env['res.partner'].browse(
                response.qcontext['partner']
            )

        if not partner_id:
            return response

        payment_acquirer = set([])
        if partner_id.payment_acquirer_ids:
            for payment in partner_id.payment_acquirer_ids.filtered(
                lambda p: p.state in ('enabled', 'test')
            ):
                payment_acquirer.add(payment)
        else:
            domain = expression.AND(
                [
                    [
                        '&',
                        ('state', 'in', ['enabled', 'test']),
                        ('company_id', '=', order.company_id.id),
                    ],
                    [
                        '|',
                        ('website_id', '=', False),
                        ('website_id', '=', request.website.id),
                    ],
                    [
                        '|',
                        ('country_ids', '=', False),
                        (
                            'country_ids',
                            'in',
                            [order.partner_id.country_id.id],
                        ),
                    ],
                    [('is_public', '=', True)],
                ]
            )

            for payment in (
                request.env['payment.acquirer'].sudo().search(domain)
            ):
                payment_acquirer.add(payment)

        if payment_acquirer:
            response.qcontext['acquirers'] = list(payment_acquirer)

        return response
