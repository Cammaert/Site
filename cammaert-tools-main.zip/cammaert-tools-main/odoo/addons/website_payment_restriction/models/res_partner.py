# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    payment_acquirer_ids = fields.Many2many(
        comodel_name='payment.acquirer',
        relation='res_partner_payment_acquirer_rel',
        column1='partner_id',
        column2='payment_acquirer_id',
        string='Payment Acquirer',
    )
