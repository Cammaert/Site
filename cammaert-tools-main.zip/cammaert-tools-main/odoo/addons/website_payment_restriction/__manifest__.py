# -*- coding: utf-8 -*-
{
    'name': 'Website Payment Restriction',
    'version': '14.0.1.0.1',
    'author': 'Great-IT',
    'category': 'Hidden',
    'summary': 'Restriction payment options on website',
    'depends': ['website_payment'],
    'sequence': 1000,
    'website': '',
    'data': ['views/res_partner.xml', 'views/payment_acquirer.xml'],
    'demo': [],
    'installable': True,
}
