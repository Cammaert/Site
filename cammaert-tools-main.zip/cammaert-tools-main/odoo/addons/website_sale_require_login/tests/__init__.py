# -*- coding: utf-8 -*-
from . import test_checkout
