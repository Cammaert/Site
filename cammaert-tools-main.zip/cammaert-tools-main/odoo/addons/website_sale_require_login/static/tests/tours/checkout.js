odoo.define("wbesite_sale_require_login.shop_buy", function(require) {
    "use strict";

    var tour = require("web_tour.tour");

    tour.register(
        "shop_buy_checkout_required_login_website",
        {
            test: true,
            url: "/shop",
        },
        [
            {
                content: "search pedal bin",
                trigger: 'form input[name="search"]',
                run: "text pedal bin",
            },
            {
                content: "search pedal bin",
                trigger: 'form:has(input[name="search"]) .oe_search_button',
            },
            {
                content: "select pedal bin",
                trigger: '.oe_product_cart:first a:contains("Pedal Bin")',
            },
            {
                id: "add_to_cart",
                content: "click on add to cart",
                trigger: '#add_to_cart',
                run: "click"
            },
            {
                content: "login and checkout button",
                trigger: 'a[href="/web/login?redirect=/shop/checkout?express=1"]',
                run: "click"
            },
        ]
    );
});
