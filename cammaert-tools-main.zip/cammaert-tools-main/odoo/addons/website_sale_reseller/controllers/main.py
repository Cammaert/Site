# -*- coding: utf-8 -*-
import json

from odoo import http
from odoo.exceptions import ValidationError
from odoo.http import request

from odoo.addons.base.models.ir_qweb_fields import nl2br
from odoo.addons.website_sale.controllers.main import (
    WebsiteSale,
    WebsiteSaleForm,
)


class WebsiteSaleFormReselller(WebsiteSaleForm):
    @http.route()
    def website_form_saleorder(self, **kwargs):
        model_record = request.env.ref('sale.model_sale_order')
        try:
            data = self.extract_data(model_record, kwargs)
        except ValidationError as e:
            return json.dumps({'error_fields': e.args[0]})

        order = request.website.sale_get_order()
        if data.get('custom') and order:
            order.write({'website_customer_feedback': nl2br(data['custom'])})

        return super().website_form_saleorder(**kwargs)


class WebsiteSaleReseller(WebsiteSale):
    def _get_reseller_profile(self, reseller_id):
        reseller_id = request.env['res.partner'].browse(reseller_id)
        website = request.website.get_current_website()
        image_url = website.image_url(reseller_id, 'image_128')
        values = {
            'id': reseller_id.id,
            'name': reseller_id.name,
            'text': '{} - {}'.format(
                reseller_id.name, reseller_id.contact_address_complete,
            ),
            'contact_address_complete': reseller_id.contact_address_complete,
            'email': reseller_id.email,
            'phone': reseller_id.phone,
            'image_url': image_url,
        }
        return values

    @http.route(
        ['/shop/cart/set_reseller'],
        type='json',
        auth='user',
        methods=['POST'],
        website=True,
        sitemap=False,
    )
    def cart_set_reseller(self, reseller, **kwargs):
        sale_order = request.website.sale_get_order()
        try:
            sale_order._set_reseller(reseller)
            reseller = None
            if sale_order.reseller_id:
                reseller = self._get_reseller_profile(
                    sale_order.reseller_id.id
                )
            return {'result': 1, 'message': 'success', 'reseller': reseller}
        except Exception as msg:
            return {'result': 0, 'message': str(msg)}

    @http.route(
        ['/shop/extra_info/get_reseller'],
        auth='user',
        website=True,
        type='json',
        sitemap=False,
    )
    def extra_info_get_reseller(self):
        order = request.website.sale_get_order()
        values = {}
        if order.reseller_id:
            values = self._get_reseller_profile(order.reseller_id.id)
            return values

        return {}

    @http.route(
        '/shop/get_reseller',
        type='http',
        auth='user',
        methods=['GET'],
        website=True,
        sitemap=False,
    )
    def reseller_read(self, query, limit=25, **post):
        keyword = '%{}%'.format(query or '')
        data = request.env['res.partner'].search_read(
            domain=[
                '&',
                ('is_reseller', '=', True),
                '|',
                ('name', '=ilike', keyword),
                ('contact_address_complete', '=ilike', keyword),
            ],
            fields=['name', 'contact_address_complete', 'email', 'phone'],
            limit=int(limit),
        )

        return json.dumps(data)

    @http.route(auth='user')
    def cart(self, access_token=None, revive='', **post):
        response = super().cart(
            access_token=access_token, revive=revive, **post
        )
        website_sale_order = response.qcontext.get('website_sale_order')
        reseller_id = website_sale_order.reseller_id
        if reseller_id:
            reseller = reseller_id.id
        else:
            reseller = False

        user = request.env.user
        user_connected_is_reseller = user.partner_id.is_reseller
        response.qcontext.update(
            reseller=reseller,
            user_connected_is_reseller=user_connected_is_reseller,
        )
        if post.get('reseller_required') == '1' and not reseller_id:
            response.qcontext.update(warning_no_reseller=True)
        return response

    @http.route(auth='user')
    def checkout(self, **post):
        return super().checkout(**post)

    @http.route(auth='user')
    def payment(self, **post):
        order = request.website.sale_get_order()
        user = request.env.user
        if not user.partner_id.is_reseller and not order.reseller_id:
            return request.redirect('/shop/extra_info?reseller_required=1')

        return super().payment(**post)

    @http.route(auth='user')
    def extra_info(self, **post):
        response = super().extra_info(**post)
        order = (
            response.qcontext.get('order') or request.website.sale_get_order()
        )
        reseller_id = order.reseller_id
        if reseller_id:
            reseller = json.dumps(
                {
                    'id': reseller_id.id,
                    'text': '{} - {}'.format(
                        reseller_id.name, reseller_id.contact_address_complete
                    ),
                }
            )
        else:
            reseller = json.dumps({})

        user = request.env.user
        user_connected_is_reseller = user.partner_id.is_reseller
        response.qcontext.update(
            reseller=reseller,
            user_connected_is_reseller=user_connected_is_reseller,
        )
        if post.get('reseller_required') == '1' and not reseller_id:
            response.qcontext.update(warning_no_reseller=True)
        return response
