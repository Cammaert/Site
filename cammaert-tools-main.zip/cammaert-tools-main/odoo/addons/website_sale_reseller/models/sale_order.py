# -*- coding: utf-8 -*-
from odoo import _, exceptions, fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    reseller_id = fields.Many2one(
        comodel_name='res.partner',
        string='Reseller',
        domain="[('is_reseller', '=', True)]",
        ondelete='restrict',
    )
    is_partner_reseller = fields.Boolean(related='partner_id.is_reseller')
    website_customer_feedback = fields.Html(string='Customer Feedback')

    def _set_reseller(self, reseller):
        if reseller:
            reseller_id = self.env['res.partner'].browse(int(reseller))
            if not reseller_id.is_reseller:
                raise exceptions.UserError(
                    _('Reseller selected is not a reseller')
                )

            self.write({'reseller_id': reseller_id.id})
        else:
            self.write({'reseller_id': False})
        return True
