# -*- coding: utf-8 -*-
{
    'name': 'Website Sale Reseller',
    'author': 'Great-IT',
    'version': '14.0.1.0.0',
    'category': 'Website/Website',
    'sequence': 1000,
    'depends': ['website_sale'],
    'data': [
        'views/sale_order.xml',
        'views/res_partner.xml',
        'views/templates.xml',
        'views/extra_info_view.xml',
        'report/sale_order_report.xml',
    ],
    'qweb': ['static/src/xml/website_reseller_info_template.xml'],
    'installable': True,
}
