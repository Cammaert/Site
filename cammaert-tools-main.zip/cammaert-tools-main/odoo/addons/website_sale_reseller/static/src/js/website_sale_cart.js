odoo.define('website_sale_reseller.website_shop_cart', function (require) {
    'use strict';

    const core = require('web.core');
    const publicWidget = require('web.public.widget');
    var qweb = core.qweb;

    publicWidget.registry.websiteForum = publicWidget.Widget.extend({
        selector: '.oe_website_sale_reseller',
        xmlDependencies: [
            '/website_sale_reseller/static/src/xml/website_reseller_info_template.xml',
        ],
        start: function () {
            var self = this;
            if ($('input.js_select2').length > 0) {
                $('input.js_select2').select2({
                    tags: false,
                    tokenSeparators: [',', ' ', '_'],
                    maximumInputLength: 35,
                    minimumInputLength: 2,
                    maximumSelectionSize: 1,
                    lastsearch: [],
                    delay: 250,
                    ajax: {
                        url: '/shop/get_reseller',
                        dataType: 'json',
                        data: function (term) {
                            return {
                                query: term,
                                limit: 50,
                            };
                        },
                        results: function (data) {
                            const ret = [];
                            _.each(data, function (x) {
                                ret.push({
                                    id: x.id,
                                    text:
                                        x.name +
                                        ' - ' +
                                        x.contact_address_complete,
                                    isNew: false,
                                });
                            });
                            self.lastsearch = ret;
                            return { results: ret };
                        },
                    },
                });
                $('input.js_select2').on(
                    'change',
                    this._onResellerSelect.bind(this)
                );
                setTimeout(function () {
                    self._getResellerProfile().then(function(data) {
                        if (Object.keys(data).length > 0) {
                            $('input.js_select2').select2('data', data);
                            self._renderResellerProfile(data);
                        } else {
                            $('a.s_website_form_send').toggleClass('disabled');
                        }
                    });
                }, 100);
            }
            return this._super.apply(this, arguments);
        },
        _getResellerProfile: function () {
            return this._rpc({
                route: '/shop/extra_info/get_reseller',
            });
        },
        _renderResellerProfile: function (data) {
            if (data && Object.keys(data).length > 0) {
                data.widget = this;
                const $reseller_info = $(
                    qweb.render('website_sale_reseller.resellerInfo', data)
                );
                $('#reseller-info').html($reseller_info);
            }
        },
        _onResellerSelect: function (ev) {
            ev.preventDefault();
            const self = this;
            const reseller_id = parseInt($('input.js_select2').val());
            $('a.s_website_form_send').toggleClass('disabled', isNaN(parseInt(reseller_id)));
            this._rpc({
                route: '/shop/cart/set_reseller',
                params: {
                    reseller: reseller_id,
                },
            }).then(function (data) {
                if (data.reseller) {
                    self._renderResellerProfile(data.reseller);
                } else {
                    $('#reseller-info').html('<span></span>');
                }
            });
        },
    });
});
