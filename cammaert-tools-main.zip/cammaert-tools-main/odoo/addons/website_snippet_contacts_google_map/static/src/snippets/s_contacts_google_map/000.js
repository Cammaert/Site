odoo.define('website_contact_google_maps_snippet.options', function (require) {
    'use strict';

    const core = require('web.core');
    const publicWidget = require('web.public.widget');
    const config = require('web.config');
    const qweb = core.qweb;

    publicWidget.registry.DynamicContactsGoogleMap = publicWidget.Widget.extend(
        {
            selector: '.s_contacts_google_map',
            xmlDependencies: [
                '/website_snippet_contacts_google_map/static/src/xml/map_sidebar.xml',
            ],
            read_events: {
                'click [data-itemcontactid]': '_onContactClickAction',
            },
            disabledInEditableMode: false,

            mapColors: {
                lightMonoMap: [
                    {
                        featureType: 'administrative.locality',
                        elementType: 'all',
                        stylers: [
                            { hue: '#2c2e33' },
                            { saturation: 7 },
                            { lightness: 19 },
                            { visibility: 'on' },
                        ],
                    },
                    {
                        featureType: 'landscape',
                        elementType: 'all',
                        stylers: [
                            { hue: '#ffffff' },
                            { saturation: -100 },
                            { lightness: 100 },
                            { visibility: 'simplified' },
                        ],
                    },
                    {
                        featureType: 'poi',
                        elementType: 'all',
                        stylers: [
                            { hue: '#ffffff' },
                            { saturation: -100 },
                            { lightness: 100 },
                            { visibility: 'off' },
                        ],
                    },
                    {
                        featureType: 'road',
                        elementType: 'geometry',
                        stylers: [
                            { hue: '#bbc0c4' },
                            { saturation: -93 },
                            { lightness: 31 },
                            { visibility: 'simplified' },
                        ],
                    },
                    {
                        featureType: 'road',
                        elementType: 'labels',
                        stylers: [
                            { hue: '#bbc0c4' },
                            { saturation: -93 },
                            { lightness: 31 },
                            { visibility: 'on' },
                        ],
                    },
                    {
                        featureType: 'road.arterial',
                        elementType: 'labels',
                        stylers: [
                            { hue: '#bbc0c4' },
                            { saturation: -93 },
                            { lightness: -2 },
                            { visibility: 'simplified' },
                        ],
                    },
                    {
                        featureType: 'road.local',
                        elementType: 'geometry',
                        stylers: [
                            { hue: '#e9ebed' },
                            { saturation: -90 },
                            { lightness: -8 },
                            { visibility: 'simplified' },
                        ],
                    },
                    {
                        featureType: 'transit',
                        elementType: 'all',
                        stylers: [
                            { hue: '#e9ebed' },
                            { saturation: 10 },
                            { lightness: 69 },
                            { visibility: 'on' },
                        ],
                    },
                    {
                        featureType: 'water',
                        elementType: 'all',
                        stylers: [
                            { hue: '#e9ebed' },
                            { saturation: -78 },
                            { lightness: 67 },
                            { visibility: 'simplified' },
                        ],
                    },
                ],
                lillaMap: [
                    { elementType: 'labels', stylers: [{ saturation: -20 }] },
                    {
                        featureType: 'poi',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road.highway',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road.local',
                        elementType: 'labels.icon',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road.arterial',
                        elementType: 'labels.icon',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road',
                        elementType: 'geometry.stroke',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'transit',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'poi',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'poi.government',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'poi.sport_complex',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'poi.attraction',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'poi.business',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'transit',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'transit.station',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'landscape',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'road',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'road.highway',
                        elementType: 'geometry.fill',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                    {
                        featureType: 'water',
                        elementType: 'geometry',
                        stylers: [
                            { hue: '#2d313f' },
                            { visibility: 'on' },
                            { lightness: 5 },
                            { saturation: -20 },
                        ],
                    },
                ],
                blueMap: [
                    { stylers: [{ hue: '#00ffe6' }, { saturation: -20 }] },
                    {
                        featureType: 'road',
                        elementType: 'geometry',
                        stylers: [
                            { lightness: 100 },
                            { visibility: 'simplified' },
                        ],
                    },
                    {
                        featureType: 'road',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }],
                    },
                ],
                retroMap: [
                    {
                        featureType: 'administrative',
                        elementType: 'all',
                        stylers: [{ visibility: 'on' }, { lightness: 33 }],
                    },
                    {
                        featureType: 'landscape',
                        elementType: 'all',
                        stylers: [{ color: '#f2e5d4' }],
                    },
                    {
                        featureType: 'poi.park',
                        elementType: 'geometry',
                        stylers: [{ color: '#c5dac6' }],
                    },
                    {
                        featureType: 'poi.park',
                        elementType: 'labels',
                        stylers: [{ visibility: 'on' }, { lightness: 20 }],
                    },
                    {
                        featureType: 'road',
                        elementType: 'all',
                        stylers: [{ lightness: 20 }],
                    },
                    {
                        featureType: 'road.highway',
                        elementType: 'geometry',
                        stylers: [{ color: '#c5c6c6' }],
                    },
                    {
                        featureType: 'road.arterial',
                        elementType: 'geometry',
                        stylers: [{ color: '#e4d7c6' }],
                    },
                    {
                        featureType: 'road.local',
                        elementType: 'geometry',
                        stylers: [{ color: '#fbfaf7' }],
                    },
                    {
                        featureType: 'water',
                        elementType: 'all',
                        stylers: [{ visibility: 'on' }, { color: '#acbcc9' }],
                    },
                ],
                flatMap: [
                    { stylers: [{ visibility: 'off' }] },
                    {
                        featureType: 'road',
                        stylers: [{ visibility: 'on' }, { color: '#ffffff' }],
                    },
                    {
                        featureType: 'road.arterial',
                        stylers: [{ visibility: 'on' }, { color: '#fee379' }],
                    },
                    {
                        featureType: 'road.highway',
                        stylers: [{ visibility: 'on' }, { color: '#fee379' }],
                    },
                    {
                        featureType: 'landscape',
                        stylers: [{ visibility: 'on' }, { color: '#f3f4f4' }],
                    },
                    {
                        featureType: 'water',
                        stylers: [{ visibility: 'on' }, { color: '#7fc8ed' }],
                    },
                    {},
                    {
                        featureType: 'road',
                        elementType: 'labels',
                        stylers: [{ visibility: 'on' }],
                    },
                    {
                        featureType: 'poi.park',
                        elementType: 'geometry.fill',
                        stylers: [{ visibility: 'on' }, { color: '#83cead' }],
                    },
                    { elementType: 'labels', stylers: [{ visibility: 'on' }] },
                    {
                        featureType: 'landscape.man_made',
                        elementType: 'geometry',
                        stylers: [{ weight: 0.9 }, { visibility: 'off' }],
                    },
                ],
                cobaltMap: [
                    {
                        featureType: 'all',
                        elementType: 'all',
                        stylers: [
                            { invert_lightness: true },
                            { saturation: 10 },
                            { lightness: 30 },
                            { gamma: 0.5 },
                            { hue: '#435158' },
                        ],
                    },
                ],
                cupertinoMap: [
                    {
                        featureType: 'water',
                        elementType: 'geometry',
                        stylers: [{ color: '#a2daf2' }],
                    },
                    {
                        featureType: 'landscape.man_made',
                        elementType: 'geometry',
                        stylers: [{ color: '#f7f1df' }],
                    },
                    {
                        featureType: 'landscape.natural',
                        elementType: 'geometry',
                        stylers: [{ color: '#d0e3b4' }],
                    },
                    {
                        featureType: 'landscape.natural.terrain',
                        elementType: 'geometry',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'poi.park',
                        elementType: 'geometry',
                        stylers: [{ color: '#bde6ab' }],
                    },
                    {
                        featureType: 'poi',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'poi.medical',
                        elementType: 'geometry',
                        stylers: [{ color: '#fbd3da' }],
                    },
                    {
                        featureType: 'poi.business',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road',
                        elementType: 'geometry.stroke',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road.highway',
                        elementType: 'geometry.fill',
                        stylers: [{ color: '#ffe15f' }],
                    },
                    {
                        featureType: 'road.highway',
                        elementType: 'geometry.stroke',
                        stylers: [{ color: '#efd151' }],
                    },
                    {
                        featureType: 'road.arterial',
                        elementType: 'geometry.fill',
                        stylers: [{ color: '#ffffff' }],
                    },
                    {
                        featureType: 'road.local',
                        elementType: 'geometry.fill',
                        stylers: [{ color: 'black' }],
                    },
                    {
                        featureType: 'transit.station.airport',
                        elementType: 'geometry.fill',
                        stylers: [{ color: '#cfb2db' }],
                    },
                ],
                carMap: [
                    {
                        featureType: 'administrative',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'poi',
                        stylers: [{ visibility: 'simplified' }],
                    },
                    {
                        featureType: 'road',
                        stylers: [{ visibility: 'simplified' }],
                    },
                    {
                        featureType: 'water',
                        stylers: [{ visibility: 'simplified' }],
                    },
                    {
                        featureType: 'transit',
                        stylers: [{ visibility: 'simplified' }],
                    },
                    {
                        featureType: 'landscape',
                        stylers: [{ visibility: 'simplified' }],
                    },
                    {
                        featureType: 'road.highway',
                        stylers: [{ visibility: 'off' }],
                    },
                    {
                        featureType: 'road.local',
                        stylers: [{ visibility: 'on' }],
                    },
                    {
                        featureType: 'road.highway',
                        elementType: 'geometry',
                        stylers: [{ visibility: 'on' }],
                    },
                    {
                        featureType: 'water',
                        stylers: [{ color: '#84afa3' }, { lightness: 52 }],
                    },
                    { stylers: [{ saturation: -77 }] },
                    { featureType: 'road' },
                ],
                bwMap: [
                    { stylers: [{ hue: '#00ffe6' }, { saturation: -100 }] },
                    {
                        featureType: 'road',
                        elementType: 'geometry',
                        stylers: [
                            { lightness: 100 },
                            { visibility: 'simplified' },
                        ],
                    },
                    {
                        featureType: 'road',
                        elementType: 'labels',
                        stylers: [{ visibility: 'off' }],
                    },
                ],
            },

            init: function () {
                this._super.apply(this, arguments);
                this.data = [];
                this.contacts = [];
                this.markers = [];
                this.renderedContent = '';
                this.isDesplayedAsMobile = config.device.isMobile;
                this.uniqueId = _.uniqueId(
                    's_dynamic_snippet_contacts_google_map_'
                );
                this.template_key =
                    'website_snippet_contacts_google_map.sidebar_list_content';
                this.gmap = false;
            },

            willStart: function () {
                const self = this;
                return this._super.apply(this, arguments).then(() =>
                    Promise.all([
                        self._fetchData(),
                        self._manageWarningMessageVisibility(),
                        // self._toggleVisibility(),
                    ])
                );
            },

            _isConfigComplete: function () {
                return (
                    this.$el.get(0).dataset.templateKey !== undefined &&
                    this.$el.get(0).dataset.contactCategoryId !== undefined
                );
            },

            _getSearchDomain: function () {
                return [
                    [
                        'category_id',
                        'child_of',
                        parseInt(this.$el.get(0).dataset.contactCategoryId),
                    ],
                ];
            },

            _fetchData: function () {
                if (this._isConfigComplete()) {
                    const contactCategoryId = parseInt(
                        this.$el.get(0).dataset.contactCategoryId
                    );
                    const templateKey =
                        this.$el.get(0).dataset.templateKey || null;
                    const params = {
                        filter_id: parseInt(this.$el.get(0).dataset.filterId),
                        template_key: templateKey,
                        limit: 50,
                        search_domain: this._getSearchDomain(),
                    };
                    if (!templateKey || !contactCategoryId) {
                        return new Promise((resolve) => {
                            this.data = [];
                            resolve();
                        });
                    }
                    params.snippet_contacts_google_map = true;
                    return this._rpc({
                        route: '/website/snippet/filters',
                        params: params,
                    }).then((data) => {
                        this.data = data[0];
                        this.contacts = data[1];
                    });
                } else {
                    return new Promise((resolve) => {
                        this.data = [];
                        resolve();
                    });
                }
            },

            _loadMap: async function () {
                if (
                    typeof google !== 'object' ||
                    typeof google.maps !== 'object'
                ) {
                    await new Promise((resolve) => {
                        this.trigger_up('gmap_api_request', {
                            editableMode: this.editableMode,
                            onSuccess: () => resolve(),
                        });
                    });
                    // The animation will be restarted for all maps as soon as the
                    // google map script has been executed.
                    return;
                }

                // Define a default map's colors set
                const std = [];
                new google.maps.StyledMapType(std, { name: 'Std Map' });

                // Default options, will be overwritten by the user
                const myOptions = {
                    zoom: 12,
                    center: new google.maps.LatLng(50.854975, 4.3753899),
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    panControl: false,
                    zoomControl: false,
                    mapTypeControl: false,
                    streetViewControl: false,
                    scrollwheel: false,
                    mapTypeControlOptions: {
                        mapTypeIds: [
                            google.maps.MapTypeId.ROADMAP,
                            'map_style',
                            'satellite',
                        ],
                    },
                };

                // Render Map
                const mapC = this.$el.find('.contact_map_container');
                this.gmap = new google.maps.Map(mapC.get(0), myOptions);

                // Update GPS position
                const p = this.el.dataset.mapGps
                    .substring(1)
                    .slice(0, -1)
                    .split(',');

                const gps = new google.maps.LatLng(p[0], p[1]);
                this.gmap.setCenter(gps);

                // Update Map on screen resize
                google.maps.event.addDomListener(window, 'resize', () => {
                    this.gmap.setCenter(gps);
                });

                this.gmap.setMapTypeId(
                    google.maps.MapTypeId[this.el.dataset.mapType]
                ); // Update Map Type
                this.gmap.setZoom(parseInt(this.el.dataset.mapZoom)); // Update Map Zoom

                // Update Map Color
                const mapColorAttr = this.el.dataset.mapColor;
                if (mapColorAttr) {
                    const mapColor = this.mapColors[mapColorAttr];
                    this.gmap.mapTypes.set(
                        'map_style',
                        new google.maps.StyledMapType(mapColor, {
                            name: 'Styled Map',
                        })
                    );
                    this.gmap.setMapTypeId('map_style');
                }
            },

            /**
             * @override
             */
            start: function () {
                return this._super
                    .apply(this, arguments)
                    .then(() => Promise.all([this._loadMap(), this._render()]));
            },
            async _manageWarningMessageVisibility() {
                this.$el
                    .find('.missing_option_warning')
                    .toggleClass(
                        'd-none',
                        false /* this._isConfigComplete() && !this.editableMode */
                    );
            },
            /**
             * Method to be overridden in child components in order to prepare QWeb
             * options.
             * @private
             */
            _getQWebRenderOptions: function () {
                return {
                    data: this.data,
                    uniqueId: this.uniqueId,
                };
            },
            /**
             * Method to be overridden in child components in order to prepare content
             * before rendering.
             * @private
             */
            _prepareContent: function () {
                this.renderedContent = qweb.render(
                    this.template_key,
                    this._getQWebRenderOptions()
                );
            },
            /**
             *
             * @private
             */
            _render: function () {
                if (this.data.length > 0) {
                    this._prepareContent();
                } else {
                    this.renderedContent = '';
                    // this._prepareContent();
                }
                this._renderContent();
            },
            /**
             *
             * @private
             */
            _renderContent: function () {
                this.$el
                    .find('.contact_map_sidebar')
                    .html(this.renderedContent);
                setTimeout(() => {
                    this._renderGeolocation();
                }, 1000);
            },
            _createMarker: function (latLng, record_id) {
                const options = {
                    position: latLng,
                    map: this.gmap,
                    animation: google.maps.Animation.DROP,
                    _odooRecordId: record_id,
                };
                if (this.el.dataset.pinStyle === 'flat') {
                    options.icon =
                        '/website/static/src/img/snippets_thumbs/s_google_map_marker.png';
                }
                const marker = new google.maps.Marker(options);
                marker.addListener('click', () =>
                    this._scrollElementTo(record_id)
                );
                this.markers.push(marker);
            },
            _scrollElementTo: function (record_id) {
                this._toggleContactActive();
                const contentEl = this.$el.find('.dynamic_snippet_template').offset();
                const mapsEl = this.$el.find('.contact_map_container');
                const centerElPosition =
                    mapsEl.height() / 2 + mapsEl.offset().top;

                const contactEl = this.$el.find(
                    'li[data-itemcontactid="' + record_id + '"]'
                );
                const contactElHeight = contactEl.height();
                const contactElTop = contactEl.offset().top;
                const currentScrollTo = this.$el
                    .find('.contact_map_sidebar')
                    .get(0).scrollTop;
                let scrollTo = 0;
                if (currentScrollTo === 0 && contactElTop < centerElPosition) {
                    scrollTo = 0;
                } else if (
                    contactElTop < centerElPosition ||
                    contactElTop > centerElPosition
                ) {
                    scrollTo =
                        contactElTop +
                        (Math.abs(currentScrollTo) -
                        2.5 * contactElHeight) - contentEl.top;
                } else {
                    scrollTo = centerElPosition;
                }
                contactEl.toggleClass('active');
                this.$el.find('.contact_map_sidebar').animate(
                    {
                        scrollTop: scrollTo,
                    },
                    1000
                );
            },
            _renderGeolocation: function () {
                let latLng;
                if (this.contacts.length && this.gmap) {
                    _.each(this.contacts, (contact) => {
                        if (
                            contact.fields.partner_latitude &&
                            contact.fields.partner_longitude
                        ) {
                            latLng = new google.maps.LatLng(
                                parseFloat(contact.fields.partner_latitude),
                                parseFloat(contact.fields.partner_longitude)
                            );
                            this._createMarker(latLng, contact.fields.id);
                        }
                    });
                    this._mapCenter();
                    this._renderButtons();
                }
            },
            _updateMapSetting: function () {
                this.gmap.setOptions({
                    panControl: true,
                    zoomControl: true,
                    mapTypeControl: true,
                });
            },
            /**
             * Centering map
             */
            _mapCenter: function () {
                if (!this.gmap || this.editableMode) {
                    return false;
                }
                this._updateMapSetting();
                const mapBounds = new google.maps.LatLngBounds();

                _.each(this.markers, function (marker) {
                    mapBounds.extend(marker.getPosition());
                });
                this.gmap.fitBounds(mapBounds);

                google.maps.event.addListenerOnce(this.gmap, 'idle', () => {
                    google.maps.event.trigger(this.gmap, 'resize');
                    if (this.gmap.getZoom() > 17) this.gmap.setZoom(17);
                });
            },
            /**
             *
             * @param visible
             * @private
             */
            _toggleVisibility: function () {
                const visible = this.data.length > 0;
                this.$el.find('.map_sidebar').toggleClass('d-none', !visible);
            },
            _onContactClickAction: function (ev) {
                ev.stopPropagation();
                if ($(ev.currentTarget).hasClass('active')) {
                    $(ev.currentTarget).toggleClass('active');
                    this._mapCenter();
                    return;
                } else {
                    this._toggleContactActive();
                    const contactId = $(ev.currentTarget)
                        .data('itemcontactid')
                        .toString();
                    $(ev.currentTarget).addClass('active');
                    const marker = _.find(this.markers, (m) => {
                        return m._odooRecordId === contactId;
                    });
                    if (marker) {
                        this.gmap.panTo(marker.getPosition());
                        setTimeout(() => {
                            this.gmap.setZoom(17);
                        }, 500);
                    }
                }
            },
            _clearContent: function () {
                const $contactMapSidebar = this.$el.find(
                    '.contact_map_sidebar'
                );
                if ($contactMapSidebar) {
                    $contactMapSidebar.html('');
                }
            },
            destroy: function () {
                this._clearContent();
                this._super.apply(this, arguments);
            },
            _toggleContactActive: function () {
                this.$el.find('li.active').removeClass('active');
            },
            _renderButtons: function () {
                if (!this.$buttonCenterMap) {
                    this.$buttonCenterMap = $(
                        qweb.render(
                            'website_snippet_contacts_google_map.button_center_map',
                            {}
                        )
                    );
                    this.$buttonCenterMap.on('click', (ev) => {
                        ev.preventDefault();
                        this._mapCenter();
                    });
                }
                this.gmap.controls[google.maps.ControlPosition.RIGHT_TOP].push(
                    this.$buttonCenterMap.get(0)
                );
            },
        }
    );
});
