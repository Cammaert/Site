odoo.define('options.s_contacts_google_map_options', function (require) {
    'use strict';

    const { _t } = require('web.core');
    const options = require('web_editor.snippets.options');

    options.registry.DynamicContactsGoogleMap = options.Class.extend({
        init: function () {
            this._super.apply(this, arguments);
            this.contactCategories = {};
            this.dynamicFilterTemplates = {};
            this.dynamicFilters = {};
        },
        onBuilt: function () {
            this._super.apply(this, arguments);
            this._rpc({
                model: 'ir.model.data',
                method: 'search_read',
                kwargs: {
                    domain: [
                        ['module', '=', 'website_snippet_contacts_google_map'],
                        ['model', '=', 'website.snippet.filter'],
                    ],
                    fields: ['id', 'res_id'],
                },
            }).then((data) => {
                this.$target.get(0).dataset.filterId = data[0].res_id;
            });
        },
        selectDataAttribute (previewMode, widgetValue, params) {
            this._super.apply(this, arguments);
            if (params.attributeName === 'filterId' && previewMode === false) {
                this.$target.get(0).dataset.numberOfRecords = this.dynamicFilters[parseInt(widgetValue)].limit;
            }
        },
        _computeWidgetVisibility (widgetName, params) {
            if (widgetName === 'filter_opt') {
                return false;
            }
            return this._super.apply(this, arguments);
        },
        //--------------------------------------------------------------------------
        // Options
        //--------------------------------------------------------------------------

        /**
         * @see this.selectClass for parameters
         */
        resetMapColor(previewMode, widgetValue, params) {
            this.$target[0].dataset.mapColor = '';
        },
        /**
         * @see this.selectClass for parameters
         */
        setFormattedAddress(previewMode, widgetValue, params) {
            this.$target[0].dataset.pinAddress =
                params.gmapPlace.formatted_address;
        },
        /**
         * @see this.selectClass for parameters
         */
        async showDescription(previewMode, widgetValue, params) {
            const descriptionEl = this.$target[0].querySelector('.description');
            if (widgetValue && !descriptionEl) {
                this.$target.append(
                    $(`
                <div class="description">
                    <font>${_t('Visit us:')}</font>
                    <span>${_t(
                        'Our office is located in the northeast of Brussels. TEL (555) 432 2365'
                    )}</span>
                </div>`)
                );
            } else if (!widgetValue && descriptionEl) {
                descriptionEl.remove();
            }
        },

        //--------------------------------------------------------------------------
        // Private
        //--------------------------------------------------------------------------

        /**
         * @override
         */
        _computeWidgetState(methodName, params) {
            if (methodName === 'showDescription') {
                return this.$target[0].querySelector('.description')
                    ? 'true'
                    : '';
            }
            return this._super(...arguments);
        },
        _renderCustomXML (uiFragment) {
            return Promise.all([
                this._renderContactCategorySelector(uiFragment),
                this._renderDynamicFilterTemplatesSelector(uiFragment),
                this._renderDynamicFiltersSelector(uiFragment),
            ]);
        },
        _fetchContactsCategories() {
            return this._rpc({
                model: 'res.partner.category',
                method: 'search_read',
                kwargs: {
                    domain: [],
                    fields: ['id', 'name'],
                },
            });
        },
        _fetchDynamicFilterTemplates() {
            return this._rpc({
                route: '/website/snippet/filter_contacts_gmaps_templates',
            });
        },
        _fetchDynamicFilters() {
            return this._rpc({route: '/website/snippet/options_filters'});
        },
        async _renderContactCategorySelector(uiFragment) {
            const contactCategories = await this._fetchContactsCategories();
            for (let index in contactCategories) {
                this.contactCategories[contactCategories[index].id] =
                    contactCategories[index];
            }
            const contactCategoriesSelectorEl = uiFragment.querySelector(
                '[data-name="contact_category_opt"]'
            );
            return this._renderSelectUserValueWidgetButtons(
                contactCategoriesSelectorEl,
                this.contactCategories
            );
        },
        async _renderDynamicFilterTemplatesSelector(uiFragment) {
            const dynamicFilterTemplates = await this._fetchDynamicFilterTemplates();
            for (let index in dynamicFilterTemplates) {
                this.dynamicFilterTemplates[dynamicFilterTemplates[index].key] =
                    dynamicFilterTemplates[index];
            }
            const templatesSelectorEl = uiFragment.querySelector(
                '[data-name="template_opt"]'
            );
            return this._renderSelectUserValueWidgetButtons(
                templatesSelectorEl,
                this.dynamicFilterTemplates
            );
        },
        async _renderDynamicFiltersSelector(uiFragment) {
            const dynamicFilters = await this._fetchDynamicFilters();
            for (let index in dynamicFilters) {
                this.dynamicFilters[dynamicFilters[index].id] = dynamicFilters[index];
            }
            const filtersSelectorEl = uiFragment.querySelector('[data-name="filter_opt"]');
            return this._renderSelectUserValueWidgetButtons(filtersSelectorEl, this.dynamicFilters);
        },
        async _renderSelectUserValueWidgetButtons (selectUserValueWidgetElement, data) {
            for (let id in data) {
                const button = document.createElement('we-button');
                button.dataset.selectDataAttribute = id;
                button.innerHTML = data[id].name;
                selectUserValueWidgetElement.appendChild(button);
            }
        },
    });
});
