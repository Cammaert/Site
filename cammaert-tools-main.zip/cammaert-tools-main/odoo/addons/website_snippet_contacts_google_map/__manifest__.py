# -*- coding: utf-8 -*-
{
    'name': 'Website Contact Google Maps Snippet',
    'version': '14.0.1.0.2',
    'author': 'Great-IT',
    'category': 'Hidden',
    'summary': 'Snippet Contacts Google Map',
    'depends': ['website'],
    'sequence': 1000,
    'website': '',
    'data': [
        'data/snippet_filter.xml',
        'security/rule_public_user.xml',
        'views/snippets/snippets.xml',
        'views/assets.xml',
        'views/snippets/s_contacts_google_map.xml',
    ],
    'qweb': ['static/src/xml/map_sidebar.xml'],
    'demo': [],
    'installable': True,
}
