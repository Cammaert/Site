# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

from odoo.addons.website.controllers.main import Website


class WebsiteSnippetContactGoogleMaps(Website):
    @http.route(
        '/website/snippet/filter_contacts_gmaps_templates',
        auth='public',
        website=True,
        type='json',
    )
    def get_dynamic_snippet_contacts_gmaps_template(self, filter_id=False):
        templates = (
            request.env['ir.ui.view']
            .sudo()
            .search_read(
                [
                    (
                        'key',
                        'ilike',
                        '.dynamic_filter_template_contacts_gmaps_',
                    ),
                    ('type', '=', 'qweb'),
                ],
                ['key', 'name'],
            )
        )

        return templates

    @http.route(
        '/website/snippet/filters', type='json', auth='public', website=True
    )
    def get_dynamic_filter(
        self, filter_id, template_key, limit=None, search_domain=None, **kwargs
    ):
        """ Override """

        res = super(WebsiteSnippetContactGoogleMaps, self).get_dynamic_filter(
            filter_id=filter_id,
            template_key=template_key,
            limit=limit,
            search_domain=search_domain,
        )

        if kwargs.get('snippet_contacts_google_map'):
            dynamic_filter_id = (
                request.env['website.snippet.filter']
                .sudo()
                .search(
                    [('id', '=', filter_id)] + request.website.website_domain()
                )
            )
            records = []
            if dynamic_filter_id:
                records = dynamic_filter_id._prepare_values(
                    limit, search_domain
                )

            return [res, records]

        return res
