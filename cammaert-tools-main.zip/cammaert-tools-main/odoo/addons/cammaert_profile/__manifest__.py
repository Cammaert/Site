# -*- coding: utf-8 -*-
{
    'name': 'Cammaert Profile Module',
    'author': 'Great-IT',
    'version': '14.0.1.0.2',
    'category': 'Hidden',
    'depends': [
        'l10n_be',
        'sale_management',
        'website_sale_product_show_tvac_htva',
        'website_payment_restriction',
        'product_pricelist_category',
        'contacts_maps',
        'website_snippet_contacts_google_map',
        'website_sale_require_login',
    ],
    'data': [],
    'installable': True,
}
